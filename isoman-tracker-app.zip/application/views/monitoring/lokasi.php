<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
            Lokasi
            <small>Monitoring Pasien Isoman</small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="<?= base_url('dashboard') ?>"><i class="fa fa-dashboard"></i> Beranda</a></li>
            <li class="active">Monitoring</li>
        </ol>
    </section>

    <!-- Main content -->
    <section class="content">
        <!-- row -->
        <div class="row">
            <!-- col -->
            <div class="col-md-12 col-xs-12">
                <!-- box -->
                <div class="box">
                    <div class="box-header">
                        <h3 class="box-title">Lokasi Pasien Isoman</h3>
                    </div>
                    <div class="box-body">
                        <div class="row">
                            <div class="col-md-12 col-xs-12">
                                <div class="row">
                                    <div class="col-md-5">
                                        <div class="form-group">
                                            <label>Wilayah</label>
                                            <select class="form-control select2 select2-hidden-accessible" style="width: 100%;" tabindex="-1" aria-hidden="true">
                                                <option selected="selected">Alabama</option>
                                                <option>Alaska</option>
                                                <option>California</option>
                                                <option>Delaware</option>
                                                <option>Tennessee</option>
                                                <option>Texas</option>
                                                <option>Washington</option>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label>Kecamatan</label>
                                            <select class="form-control select2 select2-hidden-accessible" style="width: 100%;" tabindex="-1" aria-hidden="true">
                                                <option selected="selected">Alabama</option>
                                                <option>Alaska</option>
                                                <option>California</option>
                                                <option>Delaware</option>
                                                <option>Tennessee</option>
                                                <option>Texas</option>
                                                <option>Washington</option>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <div class="box">
                                                <div class="box-header">
                                                    <h3 class="box-title">Pasien Isoman</h3>
                                                </div>
                                                <!-- /.box-header -->
                                                <div class="box-body">
                                                    <table id="manageTable" class="table table-bordered table-striped">
                                                        <thead>
                                                            <tr>
                                                                <th>NIK</th>
                                                                <th>Nama</th>
                                                                <th>Status</th>
                                                            </tr>
                                                        </thead>

                                                    </table>
                                                </div>
                                                <!-- /.box-body -->
                                            </div>
                                        </div>

                                    </div>
                                    <div class="col-md-7">
                                        <div id="map"></div>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                    <!-- end isi tabel -->
                </div>
                <!-- /.box -->
            </div>
            <!-- col-md-12 -->
        </div>
        <!-- /.row -->
    </section>
    <!-- /.content -->
</div>
<!-- /.content-wrapper -->

<!-- leaflet -->
<script src="https://unpkg.com/leaflet@1.3.0/dist/leaflet.js"></script>
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.7.1/dist/leaflet.css" integrity="sha512-xodZBNTC5n17Xt2atTPuE1HxjVMSvLVW9ocqUKLsCC5CXdbqCmblAshOMAS6/keqq/sMZMZ19scR4PsZChSR7A==" crossorigin="" />
<link rel="stylesheet" href="<?= base_url('assets/js/leaflet-search-master/src/leaflet-search.css') ?>" />
<script src="https://unpkg.com/leaflet@1.7.1/dist/leaflet.js" integrity="sha512-XQoYMqMTK8LvdxXYG3nZ448hOEQiglfqkJs1NOQV44cWnUrBc8PkAOcXy20w0vlaXaVUearIOBhiXZ5V3ynxwA==" crossorigin=""></script>
<script src="<?= base_url('assets/js/leaflet-search-master/src/leaflet-search.js') ?>"></script>
<!-- <script src="<?php //base_url('assets/js/leaflet-routing-machine/dist/leaflet-routing-machine.js') 
                    ?>"></script> -->
<script src="<?= base_url('assets/js/leaflet-geometryutil-master/src/leaflet.geometryutil.js') ?>"></script>

<script type="text/javascript">
    $(document).ready(function() {
        //Initialize Select2 Elements
        $('.select2').select2()

        $("#monitorMainNav").addClass('active');
        $("#lokasiMonitorSubNav").addClass('active');
    });

    var firstLatLng, firstPoint, secondLatLng, secondPoint, distance, length, polyline;

    var map = L.map('map').setView([-7.339146794104617, 108.24049641018526], 12);

    var LayerKita = L.tileLayer('http://{s}.tile.osm.org/{z}/{x}/{y}.png', {
        attribution: '&copy; <a href="http://osm.org/copyright">OpenStreetMap</a> contributors',
    });
    map.addLayer(LayerKita);

    var data = [{
            type: "Feature",
            properties: {
                nik: 93535435439,
                nama: "black",
                status: "2",
                lok_akhir: [-7.372814129734489, 108.27338638717372]
            },
            geometry: {
                type: "Point",
                coordinates: [
                    108.27146592552974,
                    -7.373197174305497
                ]
            }

        },
        {
            type: "Feature",
            properties: {
                nik: 43535435435,
                nama: "aquamarine",
                status: "1",
                lok_akhir: [-7.360317046683616, 108.20661637171222]
            },
            geometry: {
                type: "Point",
                coordinates: [
                    108.20661637171222,
                    -7.360317046683616
                ]
            }

        }
    ];

    //set warna status
    function getColor(status) {
        return status == '1' ? 'blue' : status == '2' ? 'red' : white;
    }

    // SelectPoint(lokasi) {

    // }

    //popup data pasien
    function forEachFeature(feature, layer) {
        SelectPoint(feature.properties.lok_akhir);
        var popupContent = "<h1>Pasien <h1></br>" +
            "Nama: " + feature.properties.nama +
            "</br> NIK: " + feature.properties.nik + "</br>" +
            'Status: ' + feature.properties.status;

        if (feature.properties && feature.properties.popupContent) {
            popupContent += feature.properties.popupContent;
        }
        layer.bindPopup(popupContent);
    };

    var bbTeam = L.geoJSON(data, {
        onEachFeature: forEachFeature,
        pointToLayer: function(feature, latlng) {
            return L.circleMarker(latlng, {
                radius: 6,
                opacity: .5,
                //color: "#000",
                color: getColor(feature.properties.status),
                fillColor: getColor(feature.properties.status),
                fillOpacity: 0.8

            }).bindTooltip(feature.properties.nama);

        }
    }).addTo(map);
    //bbTeam.addData(data);
    console.log(bbTeam);
    //bbTeam.addTo(map);
</script>